package exemplocrud;

public class Principal extends javax.swing.JFrame {

    public Principal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jdpPrincipal = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        cadastro = new javax.swing.JMenu();
        mnCadFunc = new javax.swing.JMenuItem();
        mnCadEstoque = new javax.swing.JRadioButtonMenuItem();
        jMenu4 = new javax.swing.JMenu();
        mnConsFunc = new javax.swing.JRadioButtonMenuItem();
        mnConsEstoque = new javax.swing.JRadioButtonMenuItem();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jdpPrincipal.setBackground(new java.awt.Color(255, 153, 102));

        javax.swing.GroupLayout jdpPrincipalLayout = new javax.swing.GroupLayout(jdpPrincipal);
        jdpPrincipal.setLayout(jdpPrincipalLayout);
        jdpPrincipalLayout.setHorizontalGroup(
            jdpPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 568, Short.MAX_VALUE)
        );
        jdpPrincipalLayout.setVerticalGroup(
            jdpPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 334, Short.MAX_VALUE)
        );

        cadastro.setText("Cadastro");

        mnCadFunc.setText("Funcionario");
        mnCadFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnCadFuncActionPerformed(evt);
            }
        });
        cadastro.add(mnCadFunc);

        mnCadEstoque.setSelected(true);
        mnCadEstoque.setText("Estoque");
        mnCadEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnCadEstoqueActionPerformed(evt);
            }
        });
        cadastro.add(mnCadEstoque);

        jMenuBar1.add(cadastro);

        jMenu4.setText("Consultar");

        mnConsFunc.setSelected(true);
        mnConsFunc.setText("Funcionario");
        mnConsFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnConsFuncActionPerformed(evt);
            }
        });
        jMenu4.add(mnConsFunc);

        mnConsEstoque.setSelected(true);
        mnConsEstoque.setText("Estoque");
        mnConsEstoque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnConsEstoqueActionPerformed(evt);
            }
        });
        jMenu4.add(mnConsEstoque);

        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jdpPrincipal)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jdpPrincipal)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnCadFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnCadFuncActionPerformed
        // TODO add your handling code here:
        ConsultarCliente consultaCliente = new ConsultarCliente(jdpPrincipal);
        this.jdpPrincipal.add(consultaCliente);
        consultaCliente.setVisible(true);
    }//GEN-LAST:event_mnCadFuncActionPerformed

    private void mnCadEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnCadEstoqueActionPerformed
        
    }//GEN-LAST:event_mnCadEstoqueActionPerformed

    private void mnConsFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnConsFuncActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mnConsFuncActionPerformed

    private void mnConsEstoqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnConsEstoqueActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_mnConsEstoqueActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu cadastro;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JDesktopPane jdpPrincipal;
    private javax.swing.JRadioButtonMenuItem mnCadEstoque;
    private javax.swing.JMenuItem mnCadFunc;
    private javax.swing.JRadioButtonMenuItem mnConsEstoque;
    private javax.swing.JRadioButtonMenuItem mnConsFunc;
    // End of variables declaration//GEN-END:variables
}
